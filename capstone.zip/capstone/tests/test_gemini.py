
import os
import time
from google import genai
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    print("❌ GEMINI_API_KEY not found in .env")
else:
    try:
        client = genai.Client(api_key=api_key)

        for attempt in range(3):
            try:
                response = client.models.generate_content(
                    model="gemini-3.8-flash",
                    contents="Reply with exactly: Gemini API is working"
                )

                print("✅ Gemini API is working!")
                print("Response:", response.text)
                break

            except Exception as e:
                error = str(e)

                if "503" in error and attempt < 2:
                    print(f"Temporary server issue. Retry {attempt + 1}/3...")
                    time.sleep(3 * (attempt + 1))
                else:
                    print("❌ Gemini API request failed:")
                    print(error)
                    break

    except Exception as e:
        print("❌ Could not initialize Gemini client:")
        print(e)
