"""Unit tests for backend business logic and underwriting services."""
import pytest
from backend.schemas import ApplicantInput, LoanAmountRequest, VehicleFilterRequest, ExplainRequest
from backend.services.eligibility import predict_eligibility
from backend.services.loan_amount import calculate_sanctioned_loan
from backend.services.vehicles import get_affordable_vehicles, get_single_vehicle
from backend.services.explain import explain_decision
from backend.rag.retriever import retrieve_passages


def test_approved_applicant_prediction():
    """Verify applicant with strong financials and credit score is Approved."""
    app = ApplicantInput(
        monthly_income=85000,
        credit_score=745,
        employment_years=6.0,
        existing_monthly_emi=12000,
        requested_tenure_years=5,
        down_payment_available=150000,
        age=32,
        employment_type="Salaried"
    )
    decision, confidence, summary, factors = predict_eligibility(app)
    assert decision == "Approved"
    assert confidence > 0.70
    assert len(factors) > 0


def test_rejected_credit_score_floor():
    """Verify applicant below mandatory credit score floor 650 is Rejected."""
    app = ApplicantInput(
        monthly_income=65000,
        credit_score=580,
        employment_years=4.0,
        existing_monthly_emi=5000,
        requested_tenure_years=5,
        down_payment_available=100000
    )
    decision, confidence, summary, factors = predict_eligibility(app)
    assert decision == "Rejected"
    assert any("650" in f for f in factors)


def test_rejected_excessive_foir():
    """Verify applicant whose existing EMIs exceed allowable debt burden is Rejected."""
    app = ApplicantInput(
        monthly_income=40000,
        credit_score=720,
        employment_years=3.0,
        existing_monthly_emi=25000,  # 62.5% of income
        requested_tenure_years=5,
        down_payment_available=50000
    )
    decision, confidence, summary, factors = predict_eligibility(app)
    assert decision == "Rejected"


def test_sanctioned_loan_calculation():
    """Verify sanctioned loan amount respects FOIR limits and interest rate tiers."""
    req = LoanAmountRequest(
        monthly_income=85000,
        credit_score=745,
        existing_monthly_emi=12000,
        requested_tenure_years=5
    )
    res = calculate_sanctioned_loan(req)
    assert res.sanctioned_amount > 0
    assert res.interest_rate == 9.50  # 700-749 tier
    assert res.tenure_years == 5
    assert res.max_permissible_emi <= (85000 * 0.50) - 12000 + 1.0


def test_vehicle_filtering_and_retrieval():
    """Verify vehicle recommendations are within purchasing budget."""
    req = VehicleFilterRequest(
        sanctioned_amount=800000,
        down_payment=150000,
        sort_by="price_asc"
    )
    res = get_affordable_vehicles(req)
    assert res.total_affordable > 0
    total_budget = 800000 + 150000
    for v in res.vehicles:
        assert v.on_road_price <= total_budget


def test_single_vehicle_lookup():
    """Verify vehicle lookup returns full details including brochure text."""
    v = get_single_vehicle("VEH001")
    assert v is not None
    assert v.make == "Maruti Suzuki"
    assert v.model == "Alto K10"
    assert v.brochure_text is not None
    assert len(v.brochure_text) > 100


def test_policy_retriever():
    """Verify semantic RAG retriever retrieves relevant policy chunks."""
    passages = retrieve_passages("credit score cut-off floor 650", top_k=2, doc_type="policy")
    assert len(passages) > 0
    assert "policy" in passages[0]["source"].lower()
    assert passages[0]["text"] is not None


def test_grounded_policy_explanation():
    """Verify policy explanation cites specific policy sections and numbers."""
    req = ExplainRequest(
        decision="Rejected",
        monthly_income=22000,
        credit_score=580,
        employment_years=1.0,
        existing_monthly_emi=9000,
        requested_tenure_years=5
    )
    res = explain_decision(req)
    assert res.decision == "Rejected"
    assert "Section 3.1" in res.explanation or "650" in res.explanation
    assert len(res.policy_sources) > 0
