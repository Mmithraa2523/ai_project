"""Integration tests for FastAPI endpoints."""
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_health_endpoint():
    """GET /health should return 200 OK and health status."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] in ["ok", "degraded"]
    assert data["database_connected"] is True


def test_predict_endpoint_approved():
    """POST /predict should return Approved for strong applicant."""
    payload = {
        "monthly_income": 85000,
        "credit_score": 745,
        "employment_years": 6.0,
        "existing_monthly_emi": 12000,
        "requested_tenure_years": 5,
        "down_payment_available": 150000,
        "age": 32,
        "employment_type": "Salaried"
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["decision"] == "Approved"
    assert data["confidence"] > 0.5


def test_predict_endpoint_rejected():
    """POST /predict should return Rejected for below-floor credit score."""
    payload = {
        "monthly_income": 22000,
        "credit_score": 580,
        "employment_years": 1.0,
        "existing_monthly_emi": 9000,
        "requested_tenure_years": 5,
        "down_payment_available": 50000
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["decision"] == "Rejected"


def test_loan_amount_endpoint():
    """POST /loan-amount should return sanctioned amount and terms."""
    payload = {
        "monthly_income": 85000,
        "credit_score": 745,
        "existing_monthly_emi": 12000,
        "requested_tenure_years": 5
    }
    response = client.post("/loan-amount", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["sanctioned_amount"] > 0
    assert data["interest_rate"] > 0
    assert data["tenure_years"] == 5


def test_vehicles_endpoint():
    """POST /vehicles should return affordable vehicles."""
    payload = {
        "sanctioned_amount": 800000,
        "down_payment": 150000,
        "sort_by": "price_asc"
    }
    response = client.post("/vehicles", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["total_affordable"] > 0
    assert len(data["vehicles"]) > 0


def test_vehicle_detail_endpoint():
    """GET /vehicles/{id} should return details of vehicle or 404."""
    # Valid vehicle
    res_valid = client.get("/vehicles/VEH001")
    assert res_valid.status_code == 200
    assert res_valid.json()["model"] == "Alto K10"

    # Invalid vehicle
    res_invalid = client.get("/vehicles/NONEXISTENT")
    assert res_invalid.status_code == 404


def test_explain_endpoint():
    """POST /explain should return grounded explanation with policy sources."""
    payload = {
        "decision": "Approved",
        "monthly_income": 85000,
        "credit_score": 745,
        "employment_years": 6.0,
        "existing_monthly_emi": 12000,
        "requested_tenure_years": 5,
        "down_payment": 150000,
        "sanctioned_amount": 800000
    }
    response = client.post("/explain", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["decision"] == "Approved"
    assert len(data["explanation"]) > 20
    assert len(data["policy_sources"]) > 0
