"""Streamlit frontend application for Intelligent Vehicle Loan Advisor."""
import os
import requests
import streamlit as st
import pandas as pd

# Backend API Configuration
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000").rstrip("/")

st.set_page_config(
    page_title="Intelligent Vehicle Loan Advisor",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling for polished, clean, professional appearance
st.markdown("""
<style>
    .main-header {
        font-size: 2.1rem;
        font-weight: 700;
        color: #1E293B;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #64748B;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 16px 20px;
        text-align: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .metric-title {
        font-size: 0.85rem;
        font-weight: 600;
        color: #64748B;
        text-transform: uppercase;
        margin-bottom: 6px;
    }
    .metric-value {
        font-size: 1.6rem;
        font-weight: 700;
        color: #0F172A;
    }
    .status-badge-approved {
        background-color: #DEF7EC;
        color: #03543F;
        padding: 6px 16px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 1.1rem;
        display: inline-block;
        border: 1px solid #31C48D;
    }
    .status-badge-rejected {
        background-color: #FDE8E8;
        color: #9B1C1C;
        padding: 6px 16px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 1.1rem;
        display: inline-block;
        border: 1px solid #F98080;
    }
    .source-box {
        background-color: #F1F5F9;
        border-left: 4px solid #3B82F6;
        padding: 12px 16px;
        margin-top: 8px;
        margin-bottom: 8px;
        border-radius: 0 8px 8px 0;
        font-size: 0.92rem;
        color: #1E293B !important;
    }
    .veh-card {
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 16px;
        background-color: #FFFFFF;
        margin-bottom: 14px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.04);
        transition: transform 0.15s ease-in-out;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Session State Initialization
# ---------------------------------------------------------------------------
if "application_evaluated" not in st.session_state:
    st.session_state.application_evaluated = False
if "applicant_data" not in st.session_state:
    st.session_state.applicant_data = {}
if "predict_result" not in st.session_state:
    st.session_state.predict_result = {}
if "loan_result" not in st.session_state:
    st.session_state.loan_result = {}
if "explain_result" not in st.session_state:
    st.session_state.explain_result = {}
if "selected_vehicle_id" not in st.session_state:
    st.session_state.selected_vehicle_id = None


# ---------------------------------------------------------------------------
# Sidebar: System Status & Backend Connectivity
# ---------------------------------------------------------------------------
with st.sidebar:
    st.subheader("System Health & Status")
    try:
        health_resp = requests.get(f"{BACKEND_URL}/health", timeout=3)
        if health_resp.status_code == 200:
            hdata = health_resp.json()
            st.success("Backend Service: Online")
            st.caption(f"DB Connected: {'Yes' if hdata.get('database_connected') else 'No'} | ML Model: {'Ready' if hdata.get('model_loaded') else 'Degraded'}")
        else:
            st.warning("Backend Degraded")
    except Exception:
        st.error(f"Cannot connect to backend at {BACKEND_URL}")
        st.info("Ensure the FastAPI backend is running via `uvicorn backend.main:app` or Docker Compose.")

    st.markdown("---")
    st.markdown("### Underwriting Standards")
    st.markdown("""
    - **Minimum CIBIL Floor**: 650
    - **Maximum Allowable FOIR**: 50.0% (55% for > ₹1L income)
    - **Minimum Experience**: 2.0 Yrs (Salaried), 3.0 Yrs (Self-Employed)
    - **Minimum Monthly Income**: ₹25,000 (Salaried), ₹35,000 (Self-Employed)
    - **Tenure**: 12 to 84 Months
    """)

    if st.button("Reset Application"):
        st.session_state.application_evaluated = False
        st.session_state.applicant_data = {}
        st.session_state.predict_result = {}
        st.session_state.loan_result = {}
        st.session_state.explain_result = {}
        st.session_state.selected_vehicle_id = None
        st.rerun()


# ---------------------------------------------------------------------------
# Main App Header
# ---------------------------------------------------------------------------
st.markdown('<div class="main-header">Intelligent Vehicle Loan Advisor</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Automated credit evaluation, policy-grounded decisioning, and vehicle recommendation engine.</div>', unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Step 1: Applicant Details Form
# ---------------------------------------------------------------------------
st.markdown("### Step 1: Applicant Details")

with st.form("applicant_form"):
    col1, col2, col3 = st.columns(3)

    with col1:
        monthly_income = st.number_input(
            "Monthly Net Income (₹)",
            min_value=10000,
            max_value=1000000,
            value=int(st.session_state.applicant_data.get("monthly_income", 75000)),
            step=5000,
            help="Verified net monthly take-home income."
        )
        employment_type = st.selectbox(
            "Employment Type",
            options=["Salaried", "Self-Employed"],
            index=0 if st.session_state.applicant_data.get("employment_type", "Salaried") == "Salaried" else 1
        )
        age = st.number_input(
            "Applicant Age (Years)",
            min_value=21,
            max_value=65,
            value=int(st.session_state.applicant_data.get("age", 32))
        )

    with col2:
        credit_score = st.number_input(
            "Credit Bureau Score (CIBIL)",
            min_value=300,
            max_value=900,
            value=int(st.session_state.applicant_data.get("credit_score", 740)),
            step=5,
            help="CIBIL or equivalent bureau credit score."
        )
        employment_years = st.number_input(
            "Continuous Employment Vintage (Years)",
            min_value=0.0,
            max_value=40.0,
            value=float(st.session_state.applicant_data.get("employment_years", 5.0)),
            step=0.5,
            help="Years of continuous employment or business operations."
        )
        existing_active_loans = st.number_input(
            "Number of Existing Active Loans",
            min_value=0,
            max_value=10,
            value=int(st.session_state.applicant_data.get("existing_active_loans", 1))
        )

    with col3:
        existing_monthly_emi = st.number_input(
            "Existing Monthly Loan EMIs (₹)",
            min_value=0,
            max_value=500000,
            value=int(st.session_state.applicant_data.get("existing_monthly_emi", 10000)),
            step=1000,
            help="Total existing monthly installment liabilities."
        )
        requested_tenure_years = st.selectbox(
            "Requested Repayment Tenure",
            options=[3, 4, 5, 7],
            index=2,
            format_func=lambda x: f"{x} Years ({x*12} Months)"
        )
        down_payment_available = st.number_input(
            "Available Upfront Down Payment (₹)",
            min_value=0,
            max_value=2000000,
            value=int(st.session_state.applicant_data.get("down_payment_available", 150000)),
            step=10000
        )

    submit_button = st.form_submit_button("Evaluate Loan Application", use_container_width=True, type="primary")

if submit_button:
    applicant_payload = {
        "monthly_income": float(monthly_income),
        "credit_score": int(credit_score),
        "employment_years": float(employment_years),
        "existing_monthly_emi": float(existing_monthly_emi),
        "requested_tenure_years": int(requested_tenure_years),
        "down_payment_available": float(down_payment_available),
        "age": int(age),
        "employment_type": employment_type,
        "existing_active_loans": int(existing_active_loans)
    }

    with st.spinner("Processing underwriting decision via ML engine and policy retriever..."):
        try:
            # 1. POST /predict
            p_res = requests.post(f"{BACKEND_URL}/predict", json=applicant_payload, timeout=8)
            if p_res.status_code != 200:
                st.error(f"Error from /predict: {p_res.text}")
                st.stop()
            predict_data = p_res.json()

            decision = predict_data["decision"]
            sanctioned_amount = 0.0
            loan_data = {}

            # 2. If Approved: POST /loan-amount
            if decision == "Approved":
                l_payload = {
                    "monthly_income": float(monthly_income),
                    "credit_score": int(credit_score),
                    "existing_monthly_emi": float(existing_monthly_emi),
                    "requested_tenure_years": int(requested_tenure_years),
                    "employment_type": employment_type
                }
                l_res = requests.post(f"{BACKEND_URL}/loan-amount", json=l_payload, timeout=8)
                if l_res.status_code == 200:
                    loan_data = l_res.json()
                    sanctioned_amount = loan_data.get("sanctioned_amount", 0.0)

            # 3. POST /explain (Grounded policy retrieval)
            exp_payload = {
                "decision": decision,
                "monthly_income": float(monthly_income),
                "credit_score": int(credit_score),
                "employment_years": float(employment_years),
                "existing_monthly_emi": float(existing_monthly_emi),
                "requested_tenure_years": int(requested_tenure_years),
                "down_payment": float(down_payment_available),
                "sanctioned_amount": float(sanctioned_amount),
                "employment_type": employment_type
            }
            exp_res = requests.post(f"{BACKEND_URL}/explain", json=exp_payload, timeout=12)
            explain_data = exp_res.json() if exp_res.status_code == 200 else {}

            # Save state
            st.session_state.application_evaluated = True
            st.session_state.applicant_data = applicant_payload
            st.session_state.predict_result = predict_data
            st.session_state.loan_result = loan_data
            st.session_state.explain_result = explain_data
            st.session_state.selected_vehicle_id = None

        except Exception as e:
            st.error(f"Failed to communicate with backend API: {e}")
            st.stop()


# ---------------------------------------------------------------------------
# Step 2: Underwriting Decision View & Policy Grounding
# ---------------------------------------------------------------------------
if st.session_state.application_evaluated:
    st.markdown("---")
    st.markdown("### Step 2: Underwriting Decision & Policy Grounding")

    p_data = st.session_state.predict_result
    l_data = st.session_state.loan_result
    e_data = st.session_state.explain_result
    app_data = st.session_state.applicant_data

    decision = p_data.get("decision", "Unknown")
    confidence = p_data.get("confidence", 0.0)

    # Decision Banner
    dec_col1, dec_col2 = st.columns([1, 3])
    with dec_col1:
        if decision == "Approved":
            st.markdown(f'<div class="status-badge-approved">✔ Decision: APPROVED</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="status-badge-rejected">✖ Decision: REJECTED</div>', unsafe_allow_html=True)
        st.write(f"**Model Confidence**: `{confidence * 100:.1f}%`")

    with dec_col2:
        st.write(f"**Underwriting Summary**: {p_data.get('summary', '')}")
        factors = p_data.get("primary_factors", [])
        if factors:
            st.write("**Evaluation Factors**:")
            for f in factors:
                st.markdown(f"- {f}")

    # If Approved: Display Sanctioned Terms Cards
    if decision == "Approved" and l_data:
        st.markdown("#### Sanctioned Loan Terms")
        kpi1, kpi2, kpi3, kpi4 = st.columns(4)
        with kpi1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Sanctioned Loan</div>
                <div class="metric-value">₹{l_data.get('sanctioned_amount', 0):,.0f}</div>
            </div>
            """, unsafe_allow_html=True)
        with kpi2:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Interest Rate</div>
                <div class="metric-value">{l_data.get('interest_rate', 0):.2f}% p.a.</div>
            </div>
            """, unsafe_allow_html=True)
        with kpi3:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Tenure</div>
                <div class="metric-value">{l_data.get('tenure_years', 0)} Years</div>
            </div>
            """, unsafe_allow_html=True)
        with kpi4:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Max Permissible EMI</div>
                <div class="metric-value">₹{l_data.get('max_permissible_emi', 0):,.0f}/mo</div>
            </div>
            """, unsafe_allow_html=True)

        # Calculation breakdown expander
        with st.expander("🔍 View Step-by-Step Sanction Amount Calculation"):
            st.markdown(f"**Methodology**: {l_data.get('methodology')}")
            steps = l_data.get("calculation_steps", {})
            st.json(steps)

    # Policy-Grounded Explanation Section
    st.markdown("#### Policy-Grounded Explanation")
    st.info(e_data.get("explanation", "No explanation available."))

    sources = e_data.get("policy_sources", [])
    if sources:
        with st.expander("📜 Official Policy Sources & Grounded Passages", expanded=False):
            for idx, s in enumerate(sources):
                st.markdown(f"**Source {idx+1}: {s.get('document')} — {s.get('section')}**")
                st.markdown(f'<div class="source-box">{s.get("passage")}</div>', unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Step 3: Affordable Vehicles Shortlist (Approved Only)
# ---------------------------------------------------------------------------
if st.session_state.application_evaluated and st.session_state.predict_result.get("decision") == "Approved":
    st.markdown("---")
    st.markdown("### Step 3: Affordable Vehicle Recommendations")

    sanctioned_amt = st.session_state.loan_result.get("sanctioned_amount", 0.0)
    down_pmt = st.session_state.applicant_data.get("down_payment_available", 0.0)
    total_budget = sanctioned_amt + down_pmt

    st.write(
        f"Based on your sanctioned loan amount of **₹{sanctioned_amt:,.0f}** and available down payment of "
        f"**₹{down_pmt:,.0f}**, your total vehicle purchasing power is **₹{total_budget:,.0f}**."
    )

    # Filter Controls
    f_col1, f_col2, f_col3 = st.columns(3)
    with f_col1:
        body_filter = st.selectbox(
            "Body Type",
            options=["All", "Hatchback", "Compact Sedan", "Sedan", "Compact SUV", "Midsize SUV", "Electric"],
            index=0
        )
    with f_col2:
        fuel_filter = st.selectbox(
            "Fuel Type",
            options=["All", "Petrol", "Diesel", "CNG", "Electric"],
            index=0
        )
    with f_col3:
        sort_by = st.selectbox(
            "Sort By",
            options=["Price: Low to High", "Price: High to Low", "Safety Stars: High to Low", "Estimated EMI: Low to High"],
            index=0
        )

    sort_map = {
        "Price: Low to High": "price_asc",
        "Price: High to Low": "price_desc",
        "Safety Stars: High to Low": "safety_desc",
        "Estimated EMI: Low to High": "emi_asc"
    }

    # Fetch vehicles from /vehicles
    veh_payload = {
        "sanctioned_amount": sanctioned_amt,
        "down_payment": down_pmt,
        "body_type": None if body_filter == "All" else body_filter,
        "fuel_type": None if fuel_filter == "All" else fuel_filter,
        "sort_by": sort_map[sort_by]
    }

    try:
        v_res = requests.post(f"{BACKEND_URL}/vehicles", json=veh_payload, timeout=8)
        if v_res.status_code == 200:
            v_data = v_res.json()
            vehicles_list = v_data.get("vehicles", [])
            guidance = v_data.get("guidance")

            if guidance:
                st.warning(guidance)
            else:
                st.write(f"Found **{len(vehicles_list)}** matching vehicles within budget.")

                # Display Vehicles Grid
                v_cols = st.columns(3)
                for i, v in enumerate(vehicles_list):
                    col = v_cols[i % 3]
                    with col:
                        st.markdown(f"""
                        <div class="veh-card">
                            <h4 style="margin-top:0; margin-bottom:4px; color:#1E293B;">{v['make']} {v['model']}</h4>
                            <p style="color:#64748B; font-size:0.88rem; margin-bottom:8px;"><strong style="color:#475569;">{v['variant']}</strong> | {v['body_type']}</p>
                            <p style="margin-bottom:4px; color:#374151;"><strong>On-Road Price:</strong> ₹{v['on_road_price']:,.0f}</p>
                            <p style="margin-bottom:4px; color:#374151;"><strong>Est. Monthly EMI:</strong> ₹{v.get('estimated_emi', 0):,.0f}</p>
                            <p style="margin-bottom:4px; color:#374151;"><strong>Efficiency:</strong> {v['mileage_kmpl_or_range']}</p>
                            <p style="margin-bottom:8px; color:#374151;"><strong>Safety Rating:</strong> {'⭐' * v['safety_rating_stars']} ({v['safety_rating_stars']} Stars)</p>
                        </div>
                        """, unsafe_allow_html=True)
                        if st.button(f"View Full Details", key=f"btn_veh_{v['vehicle_id']}"):
                            st.session_state.selected_vehicle_id = v["vehicle_id"]
                            st.rerun()

        else:
            st.error(f"Error fetching vehicles: {v_res.text}")
    except Exception as e:
        st.error(f"Failed to fetch vehicle recommendations: {e}")


# ---------------------------------------------------------------------------
# Step 4: Vehicle Detail View
# ---------------------------------------------------------------------------
if st.session_state.application_evaluated and st.session_state.selected_vehicle_id:
    st.markdown("---")
    st.markdown("### Step 4: Vehicle Detailed Specifications & Official Brochure")

    veh_id = st.session_state.selected_vehicle_id
    try:
        det_res = requests.get(f"{BACKEND_URL}/vehicles/{veh_id}", timeout=8)
        if det_res.status_code == 200:
            veh = det_res.json()

            st.markdown(f"## {veh['make']} {veh['model']} — {veh['variant']}")

            d1, d2, d3, d4 = st.columns(4)
            d1.metric("On-Road Price", f"₹{veh['on_road_price']:,.0f}")
            d2.metric("Ex-Showroom Price", f"₹{veh['ex_showroom_price']:,.0f}")
            d3.metric("Safety Rating", f"{veh['safety_rating_stars']} Stars")
            d4.metric("Warranty", f"{veh['warranty_years']} Years")

            tab1, tab2 = st.tabs(["Key Specifications", "Official Brochure Document"])

            with tab1:
                spec_df = pd.DataFrame([
                    {"Parameter": "Make / Manufacturer", "Specification": veh["make"]},
                    {"Parameter": "Model & Variant", "Specification": f"{veh['model']} ({veh['variant']})"},
                    {"Parameter": "Body Category", "Specification": veh["body_type"]},
                    {"Parameter": "Fuel & Transmission", "Specification": f"{veh['fuel_type']} | {veh['transmission']}"},
                    {"Parameter": "Engine / Battery", "Specification": veh["engine_cc_or_battery"]},
                    {"Parameter": "Power Output", "Specification": veh["power_bhp"]},
                    {"Parameter": "Fuel Efficiency / Range", "Specification": veh["mileage_kmpl_or_range"]},
                    {"Parameter": "Seating Capacity", "Specification": f"{veh['seating_capacity']} Passengers"},
                    {"Parameter": "Key Equipment & Tech", "Specification": veh["key_features"]}
                ])
                st.dataframe(spec_df, use_container_width=True, hide_index=True)

            with tab2:
                brochure_text = veh.get("brochure_text")
                if brochure_text:
                    st.markdown(brochure_text)
                else:
                    st.info("Descriptive brochure text not found for this model.")

        else:
            st.error("Vehicle detail could not be loaded.")
    except Exception as e:
        st.error(f"Failed to fetch vehicle detail: {e}")
