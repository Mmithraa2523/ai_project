# Intelligent Vehicle Loan Advisor

An end-to-end intelligent vehicle lending advisory platform that evaluates applicant eligibility, calculates sanctioned loan amounts according to institutional policy, recommends affordable vehicles from a SQLite catalogue, and provides grounded explanations with policy citations.

---

## 1. Project Overview & Architecture

The system connects credit risk evaluation with consumer vehicle discovery through a 5-step journey:
1. **Applicant Intake**: Collects financial parameters (income, credit score, vintage, existing obligations, tenure, down payment).
2. **Underwriting Decision**: Predicts loan eligibility (Approved / Rejected) using a trained Random Forest model and strict policy floors.
3. **Loan Sanctioning**: Derives allowable loan principal, interest rate, and terms using Fixed Obligation to Income Ratio (FOIR) and present value annuity calculations.
4. **Affordability Matching**: Recommends vehicles from the structured catalogue whose on-road price fits within purchasing power (sanctioned loan + down payment).
5. **Policy Grounding & Retrieval**: Provides transparent, plain-language explanations citing specific clauses from the written lending policy document.

---

## 2. Directory Structure

```text
vehicle-loan-advisor/
|-- README.md              setup, run and usage instructions
|-- requirements.txt       Python dependencies
|-- .env.example           names of required variables (no real keys)
|-- docker-compose.yml     runs backend and frontend together
|-- data/
|   |-- raw/               loan dataset, vehicle catalogue (structured)
|   |-- processed/         cleaned and feature-engineered data
|   |-- documents/
|       |-- policy/        vehicle loan policy documents
|       |-- vehicles/      brochures and descriptive vehicle documents
|-- notebooks/             EDA, model training and comparison, evaluation
|-- models/                saved trained models and preprocessing objects
|-- vectorstore/           stored embeddings of the documents
|-- backend/
|   |-- Dockerfile
|   |-- main.py            FastAPI app and route definitions
|   |-- schemas.py         Pydantic request and response models
|   |-- services/
|       |-- eligibility.py approve / reject prediction
|       |-- loan_amount.py sanctioned amount and terms
|       |-- vehicles.py    affordability filter and vehicle lookup
|       |-- explain.py     retrieval and LLM explanation
|   |-- rag/               ingestion, chunking, embeddings, retriever
|   |-- db/                SQLite setup and queries
|-- frontend/
|   |-- Dockerfile
|   |-- app.py             Streamlit application
|-- tests/                 API and logic tests
|-- docs/                  design document, evaluation report, screenshots
```

---

## 3. Quickstart & Installation

### Prerequisites
- Python 3.10+
- (Optional) Docker & Docker Compose

### Step 1: Clone & Install Dependencies
```bash
# Clone the repository and navigate into the workspace
cd "vehicle-loan-advisor"

# Create a virtual environment (optional but recommended)
python -m venv venv
# Windows:
.\venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

# Install requirements
pip install -r requirements.txt
```

### Step 2: Environment Variables
Copy the template file `.env.example` to `.env`:
```bash
cp .env.example .env
```

> **API Key Note**: The application operates out-of-the-box with 100% functionality even without an OpenAI key, using built-in semantic retrieval and local rule-grounded explanation engines. To enable live OpenAI-powered explanations, add your single key to `.env`:
> ```env
> OPENAI_API_KEY=sk-...
> ```

---

## 4. Running the Application

### Option A: Local Execution

1. **Start the FastAPI Backend**:
```bash
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```
Interactive API documentation will be available at: [http://localhost:8000/docs](http://localhost:8000/docs)

2. **Start the Streamlit Frontend** (in a separate terminal):
```bash
streamlit run frontend/app.py --server.port 8501
```
The user application will open at: [http://localhost:8501](http://localhost:8501)

---

### Option B: Docker Compose (One-Command Deployment)

Run both the backend and frontend simultaneously in isolated containers:
```bash
docker compose up --build
```
- Frontend: [http://localhost:8501](http://localhost:8501)
- Backend API Docs: [http://localhost:8000/docs](http://localhost:8000/docs)

---

## 5. Backend REST API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/health` | Reports service status, database connectivity, and ML model availability. |
| `POST` | `/predict` | Evaluates applicant eligibility (`Approved` or `Rejected`) with confidence score. |
| `POST` | `/loan-amount` | Computes sanctioned amount, interest rate, tenure, and step-by-step FOIR math. |
| `POST` | `/vehicles` | Returns affordable vehicles based on sanctioned loan + down payment. |
| `GET` | `/vehicles/{id}` | Returns full vehicle specifications and official brochure text. |
| `POST` | `/explain` | Retrieves policy passages and provides a grounded explanation with citations. |

---

## 6. Running Tests

Run the comprehensive unit and integration test suite:
```bash
pytest tests/ -v
```
All 15 test cases validate eligibility boundaries, policy formulas, vehicle filtering, brochure retrieval, and REST API contracts.

---

## 7. Documentation
- **[Design Document](docs/design_document.md)**: Architectural specifications, formula derivations, and design decisions.
- **[Evaluation Report](docs/evaluation_report.md)**: Model performance comparison (Logistic Regression, Decision Tree, Random Forest) and business risk defense.
