# Comprehensive Vehicle Loan Lending Policy (v2024.1)
**Apex Auto Finance Limited — Retail Lending Underwriting Guidelines**

---

### Section 1: Overview & Scope
1.1 **Purpose**: This policy document outlines the mandatory underwriting standards, eligibility thresholds, risk assessment criteria, and loan sanction calculation methodologies for new four-wheeler vehicle loans.
1.2 **Applicability**: Applies to all retail vehicle financing applications for salaried and self-employed individuals across India.
1.3 **Governance**: All decisions produced by automated scoring engines, loan officers, and credit committees must strictly adhere to the quantitative limits and qualitative rules set forth herein.

---

### Section 2: Applicant Age & Employment Stability Rules
2.1 **Age Limits**:
- Minimum applicant age at loan origination: **21 years**.
- Maximum applicant age at loan maturity: **65 years** for salaried individuals; **70 years** for self-employed professionals/business owners.
2.2 **Employment Experience**:
- **Salaried Applicants**: Must have a minimum of **2 years of total continuous employment experience**, with at least 6 months at the current employer. Applications with less than 2 years total experience will be declined.
- **Self-Employed Applicants**: Must demonstrate a minimum business vintage of **3 continuous years** evidenced by business registration and tax filings.

---

### Section 3: Credit Score Tiers & Minimum Threshold
3.1 **Mandatory Floor (Cut-off)**:
- A minimum credit bureau score (CIBIL or equivalent) of **650** is required for vehicle loan consideration.
- Any applicant with a credit bureau score strictly below **650** is automatically **Rejected**. No administrative or commercial exceptions are permitted for credit scores below 650.
3.2 **Risk Grading Tiers**:
- **Tier 1 (Prime)**: Credit Score **750 to 900**. Low credit risk, eligible for optimal interest rates and up to 90% Loan-to-Value (LTV).
- **Tier 2 (Standard)**: Credit Score **700 to 749**. Moderate-low credit risk, eligible for standard interest rates and up to 85% LTV.
- **Tier 3 (Sub-Standard / Moderate)**: Credit Score **650 to 699**. Moderate credit risk, subjected to conservative underwriting, standard 80% to 85% LTV, and risk-adjusted pricing.
- **Tier 4 (High Risk / Ineligible)**: Credit Score **< 650**. Non-permissible risk grade. Automatic rejection.

---

### Section 4: Income Requirements & Fixed Obligation to Income Ratio (FOIR)
4.1 **Minimum Net Monthly Income**:
- Salaried applicants: Minimum net monthly take-home income of **₹25,000**.
- Self-employed applicants: Minimum net monthly verified income of **₹35,000**.
- Applications below these income thresholds are declined due to baseline affordability constraints.
4.2 **Fixed Obligation to Income Ratio (FOIR / Debt-to-Income)**:
- **Standard Cap**: Total monthly loan repayments (including existing monthly EMIs plus proposed vehicle loan EMI) must not exceed **50.0%** of the applicant's verified monthly income.
- **High-Net-Worth Exception**: For applicants with verified monthly income exceeding **₹1,00,000**, the permissible maximum FOIR is relaxed up to **55.0%**.
- **Existing Burden Rule**: If existing monthly EMIs alone already exceed **45.0%** of monthly income, or if the remaining debt service buffer is under ₹4,000 per month, the application shall be **Rejected**.

---

### Section 5: Maximum Loan-to-Value (LTV) Limits
5.1 **Standard Vehicles**:
- Maximum allowable financing is **85%** of the vehicle's ex-showroom or on-road valuation.
- The applicant must contribute a minimum of **15%** of total vehicle cost as an upfront down payment.
5.2 **Prime Tier Advantage**:
- Applicants in Tier 1 (Credit Score >= 750) are eligible for an extended LTV of up to **90%** (minimum down payment 10%).
5.3 **Luxury / High-Value Vehicles (> ₹20,00,000)**:
- Maximum LTV is capped at **80%** (minimum down payment 20%) to mitigate asset depreciation exposure.

---

### Section 6: Loan Tenure & Interest Rate Grid
6.1 **Tenure Boundaries**:
- Permissible tenure spans from **12 months (1 year)** to a maximum of **84 months (7 years)**.
- Standard offered tenures are 36, 48, 60, and 84 months.
6.2 **Annualized Interest Rate (Fixed Reducing Balance)**:
- **Tier 1 (Score 750+)**: **8.50% p.a.**
- **Tier 2 (Score 700 - 749)**: **9.50% p.a.**
- **Tier 3 (Score 650 - 699)**: **11.00% p.a.**

---

### Section 7: Sanctioned Loan Calculation Methodology
7.1 **Step 1 — Maximum Permissible EMI**:
- Allowable FOIR Percentage = 55% if Monthly Income >= ₹1,00,000 else 50%.
- Maximum Allowable Monthly EMI Capacity = `(Monthly Income * Allowable FOIR) - Existing Monthly EMIs`.
- If Maximum Allowable Monthly EMI Capacity <= 0, the application is unviable and rejected.
7.2 **Step 2 — Financial Capacity Loan Cap**:
- Using the standard Equated Monthly Installment (EMI) Present Value formula:
  $$\text{Capacity Loan} = \frac{\text{Max EMI Capacity} \times (1 - (1 + r)^{-n})}{r}$$
  where $r$ is the monthly interest rate ($\text{Annual Rate} / 12 / 100$) and $n$ is tenure in months ($\text{Years} \times 12$).
7.3 **Step 3 — Policy Ceilings**:
- The maximum permissible single-borrower auto loan under retail policy is **₹35,00,000**.
- The final sanctioned amount cannot exceed the minimum of:
  1. The applicant's requested loan amount (if specified).
  2. The capacity-derived loan amount based on FOIR.
  3. The institutional ceiling cap of ₹35,00,000.
- Sanctioned loan amounts are rounded to the nearest multiple of ₹10,000.

---

### Section 8: Documentation & Exception Handling
8.1 **Mandatory Documentation**:
- Primary Identity & Address: Valid Aadhaar Card, PAN Card, or Passport.
- Income Verification: Last 6 months bank statements reflecting salary or business credits.
- Tax Filings: Latest 2 years Form 16 (Salaried) or ITR with computation of income (Self-Employed).
- Vehicle Paperwork: Official dealer proforma invoice and price quotation.
8.2 **Non-Negotiable Guardrails**:
- No credit score waiver below the hard cutoff of 650 is permitted under any circumstance.
- No FOIR extension beyond the 50%/55% ceiling is permitted without Senior Credit Risk Committee sign-off.
