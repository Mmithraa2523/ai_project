# Machine Learning Model Evaluation Report: Vehicle Loan Underwriting

## 1. Dataset & Preparation
- **Raw Dataset**: Synthesized historical dataset of 3,000 retail vehicle loan applications (`data/raw/loan_data.csv`).
- **Feature Engineering**:
  - `foir`: Existing Monthly EMI / (Monthly Income + 1)
  - `loan_to_income`: Requested Loan Amount / (Annual Income + 1)
  - `disposable_income`: Monthly Income - Existing Monthly EMI
  - `is_salaried`: Indicator variable for salaried vs self-employed
- **Train / Test Split**: 80% Training (2,400 records), 20% Test (600 records), stratified by class label.

---

## 2. Model Comparison & Metrics

Three classification architectures were trained and evaluated on identical test splits:

| Model Architecture | Accuracy | Precision | Recall | F1-Score | ROC-AUC | False Positives (Bad Loan Approved) | False Negatives (Good Loan Rejected) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** (Baseline) | 81.00% | 72.99% | 65.46% | 69.02% | 0.8831 | 47 | 67 |
| **Decision Tree** (max_depth=6) | 89.50% | 82.27% | 86.08% | 84.13% | 0.9349 | 36 | 27 |
| **Random Forest** (n=100, depth=8) | **94.33%** | **93.96%** | **88.14%** | **90.96%** | **0.9522** | **11** | **23** |

---

## 3. Business Problem Defense & Metric Justification

### 3.1 Cost Asymmetry in Retail Auto Financing
In retail vehicle lending, classification mistakes are inherently asymmetric:
1. **False Positive (Approving an unqualified borrower)**:
   - High financial loss: Results in non-performing assets (NPA), repossession costs, legal recovery expenses, and vehicle depreciation write-offs.
   - Cost: Estimated at 60%–80% of sanctioned principal.
2. **False Negative (Declining a qualified borrower)**:
   - Low financial loss: Represents lost interest margin and customer relationship acquisition opportunity.
   - Cost: Estimated at 8%–12% expected net margin.

### 3.2 Why Random Forest was Selected
- **Drastic Reduction in False Positives**: Random Forest dropped bad loan approvals from 47 (Logistic Regression) to just 11.
- **Superior Discriminative Power**: Achieved an ROC-AUC of **0.9522**, demonstrating clean separation across the probability spectrum.
- **Handling Non-Linear Decision Surfaces**: Successfully learns the complex, interacting policy boundaries between FOIR thresholds and credit scores.

---

## 4. Policy Alignment & Consistency
The production system applies deterministic policy guardrails in tandem with ML probabilities:
- Any credit score below 650 is rejected unconditionally.
- Existing EMI consumption exceeding 45% is barred.
- Ensures the model's predictions never conflict with written institutional lending policy.
