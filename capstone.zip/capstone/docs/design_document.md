# System Design Document: Intelligent Vehicle Loan Advisor

## 1. Executive Summary
The **Intelligent Vehicle Loan Advisor** is a comprehensive, production-grade automotive credit underwriting and recommendation platform. It answers the customer's sequential journey:
1. **Eligibility**: "Will I get a vehicle loan?"
2. **Sanctioning**: "How much will I be given and under what terms?"
3. **Affordability**: "Which vehicles can I actually afford with that amount?"
4. **Specification**: "What exactly does each of those vehicles offer?"
5. **Explainability**: "Why was this decision made, and which written policy rules govern it?"

---

## 2. System Architecture

```
+-------------------------------------------------------------------------------+
|                             Streamlit Frontend                                |
|                  (:8501 - Multi-Step Interactive Journey)                     |
+-------------------------------------------------------------------------------+
                                      |
                                      | REST API (JSON)
                                      v
+-------------------------------------------------------------------------------+
|                               FastAPI Backend                                 |
|                                   (:8000)                                     |
|  +--------------------+  +--------------------+  +-------------------------+  |
|  |  POST /predict     |  |  POST /loan-amount |  |  POST /vehicles         |  |
|  |  (Eligibility ML)  |  |  (Sanction FOIR)   |  |  GET /vehicles/{id}     |  |
|  +--------------------+  +--------------------+  +-------------------------+  |
|  +--------------------+  +--------------------+                               |
|  |  POST /explain     |  |  GET /health       |                               |
|  |  (Grounded RAG)    |  |  (Service Status)  |                               |
|  +--------------------+  +--------------------+                               |
+-------------------------------------------------------------------------------+
         |                     |                    |                    |
         v                     v                    v                    v
+-----------------+   +-----------------+  +-----------------+  +-----------------+
| Scikit-Learn ML |   | Policy Annuity  |  | SQLite Database |  | RAG Retriever   |
| (Random Forest) |   | Math Engine     |  | (Vehicles & Log)|  | & Vector Store  |
+-----------------+   +-----------------+  +-----------------+  +-----------------+
```

---

## 3. Core Underwriting Policy & Calculation Logic

### 3.1 Credit Score Hard Floor (Policy Section 3.1)
- Mandatory credit bureau floor of **650**. Any applicant with CIBIL < 650 is automatically declined with zero exceptions.
- **Risk Tiers**:
  - Tier 1 (750 - 900): 8.50% p.a. interest rate, up to 90% LTV.
  - Tier 2 (700 - 749): 9.50% p.a. interest rate, up to 85% LTV.
  - Tier 3 (650 - 699): 11.00% p.a. interest rate, up to 80-85% LTV.

### 3.2 Fixed Obligation to Income Ratio (FOIR / DTI) (Policy Section 4.2)
- Permissible total debt obligation cap:
  $$\text{FOIR Cap} = \begin{cases} 55\%, & \text{if Monthly Income} \ge ₹1,00,000 \\ 50\%, & \text{otherwise} \end{cases}$$
- Maximum allowable monthly EMI capacity:
  $$\text{Max Allowable EMI Capacity} = (\text{Monthly Income} \times \text{FOIR Cap}) - \text{Existing Monthly EMIs}$$
- Existing debt ceiling: If existing EMIs consume $> 45\%$ of monthly income, the application is declined.

### 3.3 Present Value Annuity Loan Sanction Formula (Policy Section 7.2)
The capacity loan amount is calculated by computing the Present Value ($PV$) of the allowable monthly EMI stream:
$$\text{Capacity Loan} = \frac{\text{Max Allowable EMI} \times \left(1 - (1 + r)^{-n}\right)}{r}$$
where:
- $r = \frac{\text{Annual Interest Rate}}{12 \times 100}$ (Monthly interest rate)
- $n = \text{Tenure in Years} \times 12$ (Number of monthly installments)
- Capped by the institutional retail ceiling of **₹35,00,000** and requested loan amount.
- Rounded to the nearest ₹10,000.

---

## 4. Affordability & Vehicle Recommendation (Policy Section 5)
Affordability is defined strictly by purchasing power:
$$\text{Max Purchasing Power} = \text{Sanctioned Loan Amount} + \text{Available Down Payment}$$
- Vehicles in the catalogue are filtered such that $\text{On-Road Price} \le \text{Max Purchasing Power}$.
- Estimated monthly EMI is computed assuming 85% financing over the sanctioned tenure.
- If no vehicles qualify, clear remedial guidance is provided (increasing down payment or extending tenure).

---

## 5. RAG Policy Grounding & Explainability
- **Vector Store (`vectorstore/`)**: Policy documents and vehicle brochures are chunked into structured passages with metadata (`document`, `section`, `doc_type`).
- **Retriever (`backend/rag/retriever.py`)**: Uses cosine similarity over normalized term vectors with title-boosting.
- **Single API Key Architecture**:
  - If `OPENAI_API_KEY` is provided in `.env`, the system queries OpenAI's `text-embedding-3-small` and `gpt-4o-mini` to synthesize dynamic explanations.
  - If no key is configured, the local deterministic grounded explanation engine synthesizes plain-language justifications comparing actual values against exact policy thresholds with formal section citations.
