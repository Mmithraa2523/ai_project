"""Database initialization and query package."""
