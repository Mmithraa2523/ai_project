"""SQLite database connection and query handlers."""
import os
import sqlite3
from typing import List, Dict, Any, Optional

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB_PATH = os.path.join(BASE_DIR, "data", "processed", "vehicle_loan.db")
DOCS_VEH_DIR = os.path.join(BASE_DIR, "data", "documents", "vehicles")


def get_db_connection():
    """Create and return a row-mapped SQLite connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def get_all_vehicles() -> List[Dict[str, Any]]:
    """Fetch all vehicles from catalogue."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM vehicles ORDER BY on_road_price ASC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_vehicle_by_id(vehicle_id: str) -> Optional[Dict[str, Any]]:
    """Retrieve full details of one vehicle by ID, including brochure text."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM vehicles WHERE vehicle_id = ?", (vehicle_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    veh_dict = dict(row)
    # Read brochure text if available
    brochure_file = veh_dict.get("brochure_filename")
    if brochure_file:
        bpath = os.path.join(DOCS_VEH_DIR, brochure_file)
        if os.path.exists(bpath):
            with open(bpath, "r", encoding="utf-8") as f:
                veh_dict["brochure_text"] = f.read()
    return veh_dict


def filter_vehicles(
    max_budget: float,
    max_emi: Optional[float] = None,
    body_type: Optional[str] = None,
    fuel_type: Optional[str] = None,
    sort_by: Optional[str] = "price_asc",
    annual_rate: float = 0.095,
    tenure_years: int = 5
) -> List[Dict[str, Any]]:
    """Filter vehicles by affordability and specifications."""
    vehicles = get_all_vehicles()
    filtered = []

    # Monthly rate for EMI estimation
    r = (annual_rate / 12)
    n = max(12, tenure_years * 12)

    for v in vehicles:
        price = v["on_road_price"]
        # Affordability condition: On-road price <= max_budget
        if price > max_budget:
            continue

        # Body type filter
        if body_type and body_type.lower() != "all" and v["body_type"].lower() != body_type.lower():
            continue

        # Fuel type filter
        if fuel_type and fuel_type.lower() != "all" and v["fuel_type"].lower() != fuel_type.lower():
            continue

        # Calculate estimated loan assuming 85% LTV
        loan_est = price * 0.85
        emi_est = round(loan_est * r * ((1 + r)**n) / (((1 + r)**n) - 1))
        v["estimated_emi"] = emi_est

        if max_emi and emi_est > max_emi:
            continue

        filtered.append(v)

    # Sorting
    if sort_by == "price_desc":
        filtered.sort(key=lambda x: x["on_road_price"], reverse=True)
    elif sort_by == "emi_asc":
        filtered.sort(key=lambda x: x.get("estimated_emi", 0))
    elif sort_by == "safety_desc":
        filtered.sort(key=lambda x: x["safety_rating_stars"], reverse=True)
    else:  # default price_asc
        filtered.sort(key=lambda x: x["on_road_price"])

    return filtered


def log_application(app_data: Dict[str, Any]):
    """Log an applicant decision and calculation details."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
        INSERT INTO application_logs (
            application_id, monthly_income, credit_score, employment_years,
            existing_monthly_emi, requested_tenure_years, down_payment_available,
            decision, confidence, sanctioned_amount, interest_rate, tenure_years, explanation
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            app_data.get("application_id"),
            app_data.get("monthly_income"),
            app_data.get("credit_score"),
            app_data.get("employment_years"),
            app_data.get("existing_monthly_emi"),
            app_data.get("requested_tenure_years"),
            app_data.get("down_payment_available"),
            app_data.get("decision"),
            app_data.get("confidence"),
            app_data.get("sanctioned_amount", 0.0),
            app_data.get("interest_rate", 0.0),
            app_data.get("tenure_years", 0),
            app_data.get("explanation", "")
        ))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error logging application: {e}")
