"""FastAPI backend application for Intelligent Vehicle Loan Advisor."""
import uuid
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from backend.schemas import (
    ApplicantInput, PredictResponse,
    LoanAmountRequest, LoanAmountResponse,
    VehicleFilterRequest, VehiclesListResponse, VehicleDetailResponse,
    ExplainRequest, ExplainResponse,
    HealthResponse
)
from backend.services.eligibility import predict_eligibility, get_model
from backend.services.loan_amount import calculate_sanctioned_loan
from backend.services.vehicles import get_affordable_vehicles, get_single_vehicle
from backend.services.explain import explain_decision
from backend.db.database import get_db_connection, log_application

app = FastAPI(
    title="Intelligent Vehicle Loan Advisor API",
    description="End-to-end API for loan eligibility prediction, sanction calculation, vehicle affordability, and policy-grounded RAG explanations.",
    version="1.0.0"
)

# Enable CORS for Streamlit and external clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", response_model=HealthResponse, tags=["System"])
def health_check():
    """Reports that the service is running, with database and model readiness status."""
    db_ok = False
    try:
        conn = get_db_connection()
        conn.cursor().execute("SELECT 1")
        conn.close()
        db_ok = True
    except Exception:
        db_ok = False

    model_ok = get_model() is not None

    return HealthResponse(
        status="ok" if (db_ok and model_ok) else "degraded",
        database_connected=db_ok,
        model_loaded=model_ok,
        version="1.0.0"
    )


@app.post("/predict", response_model=PredictResponse, tags=["Underwriting"])
def predict(applicant: ApplicantInput):
    """
    Takes applicant details and returns Approved or Rejected, with the model's confidence.
    """
    try:
        decision, confidence, summary, factors = predict_eligibility(applicant)
        return PredictResponse(
            decision=decision,
            confidence=confidence,
            summary=summary,
            primary_factors=factors
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to evaluate eligibility: {str(e)}"
        )


@app.post("/loan-amount", response_model=LoanAmountResponse, tags=["Underwriting"])
def loan_amount(request: LoanAmountRequest):
    """
    For an approved applicant, returns the sanctioned amount and loan terms.
    """
    try:
        result = calculate_sanctioned_loan(request)
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to calculate sanctioned amount: {str(e)}"
        )


@app.post("/vehicles", response_model=VehiclesListResponse, tags=["Vehicles"])
def vehicles(request: VehicleFilterRequest):
    """
    Takes the sanctioned amount (and down payment) and returns the vehicles the applicant can afford.
    """
    try:
        results = get_affordable_vehicles(request)
        return results
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to filter vehicles: {str(e)}"
        )


@app.get("/vehicles/{id}", response_model=VehicleDetailResponse, tags=["Vehicles"])
def vehicle_detail(id: str):
    """
    Returns the full details and descriptive brochure text of one vehicle.
    """
    veh = get_single_vehicle(id)
    if not veh:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle with ID '{id}' not found in catalogue."
        )
    return veh


@app.post("/explain", response_model=ExplainResponse, tags=["Explainability"])
def explain(request: ExplainRequest):
    """
    Retrieves policy passages and returns a grounded explanation for the decision or amount, with sources.
    """
    try:
        explanation_result = explain_decision(request)

        # Audit log application
        app_record = {
            "application_id": f"APP-{uuid.uuid4().hex[:8].upper()}",
            "monthly_income": request.monthly_income,
            "credit_score": request.credit_score,
            "employment_years": request.employment_years,
            "existing_monthly_emi": request.existing_monthly_emi,
            "requested_tenure_years": request.requested_tenure_years,
            "down_payment_available": request.down_payment,
            "decision": request.decision,
            "confidence": 0.95,
            "sanctioned_amount": request.sanctioned_amount or 0.0,
            "interest_rate": 9.5 if request.decision == "Approved" else 0.0,
            "tenure_years": request.requested_tenure_years,
            "explanation": explanation_result.explanation
        }
        log_application(app_record)

        return explanation_result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate policy explanation: {str(e)}"
        )
