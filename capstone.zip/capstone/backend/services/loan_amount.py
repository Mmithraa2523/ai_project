"""Service to calculate sanctioned loan amount based on repayment capacity and policy ceilings."""
import math
from typing import Dict, Any, Optional
from backend.schemas import LoanAmountRequest, LoanAmountResponse


def calculate_sanctioned_loan(request: LoanAmountRequest) -> LoanAmountResponse:
    """
    Computes policy-compliant sanctioned loan amount, interest rate, and terms.
    Adheres strictly to Policy Section 4, Section 6, and Section 7.
    """
    monthly_income = request.monthly_income
    credit_score = request.credit_score
    existing_emi = request.existing_monthly_emi
    tenure_years = request.requested_tenure_years or 5
    tenure_months = tenure_years * 12

    # 1. Determine Interest Rate Grid (Policy Section 6.2)
    if credit_score >= 750:
        annual_rate = 8.50
    elif credit_score >= 700:
        annual_rate = 9.50
    elif credit_score >= 650:
        annual_rate = 11.00
    else:
        annual_rate = 12.00

    monthly_rate = (annual_rate / 100.0) / 12.0

    # 2. Determine Permissible FOIR (Policy Section 4.2)
    foir_cap = 0.55 if monthly_income >= 100000 else 0.50
    max_total_emi = monthly_income * foir_cap
    net_available_emi = max(0.0, max_total_emi - existing_emi)

    # 3. Present Value Annuity Formula (Policy Section 7.2)
    # PV = EMI * [1 - (1 + r)^(-n)] / r
    if net_available_emi > 0 and monthly_rate > 0:
        discount_factor = 1.0 - math.pow(1.0 + monthly_rate, -tenure_months)
        capacity_loan = net_available_emi * (discount_factor / monthly_rate)
    else:
        capacity_loan = 0.0

    # 4. Apply Institutional Policy Caps (Policy Section 7.3)
    policy_maximum_cap = 3500000.0  # ₹35 Lakhs ceiling for retail auto loans
    sanctioned = min(capacity_loan, policy_maximum_cap)

    # Cap by requested amount if specified and lower than capacity
    requested_amount = request.requested_loan_amount
    if requested_amount and requested_amount > 0:
        sanctioned = min(sanctioned, requested_amount)

    # Round to nearest multiple of ₹10,000
    sanctioned_amount = round(sanctioned / 10000.0) * 10000.0

    # Actual EMI for sanctioned amount
    if sanctioned_amount > 0:
        compound = math.pow(1.0 + monthly_rate, tenure_months)
        actual_emi = round(sanctioned_amount * monthly_rate * compound / (compound - 1.0), 2)
    else:
        actual_emi = 0.0

    calculation_steps = {
        "verified_monthly_income": monthly_income,
        "permissible_foir_percentage": foir_cap * 100,
        "max_allowable_total_obligation": max_total_emi,
        "existing_monthly_emi": existing_emi,
        "net_available_monthly_emi": net_available_emi,
        "applied_interest_rate_annual": annual_rate,
        "tenure_months": tenure_months,
        "theoretical_capacity_loan": round(capacity_loan, 2),
        "institutional_ceiling_cap": policy_maximum_cap,
        "final_sanctioned_amount": sanctioned_amount,
        "projected_monthly_emi": actual_emi
    }

    methodology = (
        f"Calculated based on {foir_cap*100:.0f}% maximum permissible FOIR. "
        f"Monthly income of ₹{monthly_income:,.0f} allows up to ₹{net_available_emi:,.0f} net EMI headroom. "
        f"At {annual_rate:.2f}% p.a. over {tenure_years} years ({tenure_months} months), "
        f"the present value loan capacity yields ₹{sanctioned_amount:,.0f}."
    )

    return LoanAmountResponse(
        sanctioned_amount=sanctioned_amount,
        interest_rate=annual_rate,
        tenure_years=tenure_years,
        tenure_months=tenure_months,
        max_permissible_emi=round(net_available_emi, 2),
        foir_applied=foir_cap * 100,
        methodology=methodology,
        calculation_steps=calculation_steps
    )
