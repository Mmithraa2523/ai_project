
"""Generate personalized, policy-grounded loan explanations."""

import os
from dotenv import load_dotenv

from backend.schemas import ExplainRequest, ExplainResponse, PolicySource
from backend.rag.retriever import retrieve_passages

load_dotenv(override=True)


def explain_decision(request: ExplainRequest) -> ExplainResponse:
    """Generate an applicant-specific explanation using Gemini or local fallback."""

    decision = request.decision
    income = request.monthly_income
    score = request.credit_score
    exp = request.employment_years
    emi = request.existing_monthly_emi
    sanctioned = request.sanctioned_amount or 0.0
    tenure = request.requested_tenure_years or 5
    employment_type = request.employment_type or "Salaried"

    # Retrieve relevant policy passages.
    query = (
        f"Vehicle loan {decision}; credit score {score}; "
        f"monthly income ₹{income}; existing EMI ₹{emi}; "
        f"employment experience {exp} years; "
        "minimum eligibility, credit score tier, interest rate, "
        "FOIR and sanctioned loan calculation"
    )

    raw_passages = retrieve_passages(
        query=query,
        top_k=3,
        doc_type="policy"
    )

    # Keep citations for the UI.
    policy_sources = [
        PolicySource(
            document=p["source"],
            section=p["section"],
            passage=p["text"][:380]
            + ("..." if len(p["text"]) > 380 else ""),
            relevance_score=p.get("score")
        )
        for p in raw_passages
    ]

    # Use full retrieved passages for Gemini, not the truncated UI text.
    context_text = "\n\n".join(
        f"Document: {p['source']}\n"
        f"Section: {p['section']}\n"
        f"Policy text: {p['text']}"
        for p in raw_passages
    )

    explanation = None

    # ---------------------------------------------------------
    # Gemini API
    # ---------------------------------------------------------
    api_key = os.getenv("GEMINI_API_KEY", "").strip()

    if api_key:
        try:
            from google import genai

            client = genai.Client(api_key=api_key)

            # Override this value in .env if necessary.
            model_name = os.getenv(
                "GEMINI_MODEL",
                "gemini-3.8-flash"
            )

            prompt = f"""
You are a vehicle loan policy explanation assistant.

Explain the underwriting decision to the applicant in simple,
professional, natural English. Address the applicant directly.

APPLICANT DETAILS
- Decision: {decision}
- Monthly verified income: ₹{income:,.0f}
- Credit score: {score}
- Employment type: {employment_type}
- Employment experience: {exp} years
- Existing monthly EMI: ₹{emi:,.0f}
- Requested tenure: {tenure} years
- Sanctioned amount recorded by the underwriting system: ₹{sanctioned:,.0f}

RETRIEVED POLICY DOCUMENTS
{context_text if context_text else "No relevant policy passages were retrieved."}

INSTRUCTIONS
1. Write 3-5 personalized sentences using the applicant's actual values.
2. Explain the most relevant reasons for the decision, not just the
   applicant's details.
3. Compare the applicant's values with policy thresholds only when
   those thresholds are supported by the retrieved policy text.
4. Cite the relevant document section numbers, such as Section 3.1.
5. Explain the income, credit score, employment or EMI factors that
   are relevant to this particular applicant.
6. Avoid generic openings such as "approved based on healthy credit
   fundamentals." Explain specifically why the decision was made.
7. Never invent policy rules, interest rates, thresholds or calculations.
8. Do not claim to have calculated the sanctioned amount. It was
   supplied by the underwriting system.
9. If the policy evidence is insufficient to explain a particular
   reason, clearly say so instead of guessing.
10. Do not change the supplied underwriting decision.
"""

            print(f"Calling Gemini API with model: {model_name}")

            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )

            explanation = (response.text or "").strip()

            if not explanation:
                raise ValueError("Gemini returned an empty response.")

            print("SUCCESS: Gemini generated the explanation.")

        except Exception as error:
            print(
                f"Gemini API failed: "
                f"{type(error).__name__}: {error}"
            )
            print("Using the local fallback engine.")

    else:
        print("GEMINI_API_KEY is missing. Using local fallback.")

    # Return the personalized Gemini explanation if successful.
    if explanation:
        return ExplainResponse(
            decision=decision,
            explanation=explanation,
            policy_sources=policy_sources
        )

    # ---------------------------------------------------------
    # Local fallback engine
    # ---------------------------------------------------------
    if decision.strip().lower() == "rejected":
        reasons = []

        if score < 650:
            reasons.append(
                f"your credit score of {score} is below the "
                "mandatory minimum of 650 (Section 3.1)"
            )

        minimum_income = (
            25000 if employment_type.lower() == "salaried"
            else 35000
        )

        if income < minimum_income:
            reasons.append(
                f"your monthly income of ₹{income:,.0f} is below "
                f"the minimum ₹{minimum_income:,.0f} required for "
                f"{employment_type} applicants (Section 4.1)"
            )

        minimum_experience = (
            2.0 if employment_type.lower() == "salaried"
            else 3.0
        )

        if exp < minimum_experience:
            reasons.append(
                f"your employment experience of {exp} years is below "
                f"the configured minimum of {minimum_experience} years "
                "(Section 2.2)"
            )

        if reasons:
            explanation = (
                f"Your vehicle loan application was rejected. "
                f"Based on your profile, the identified eligibility "
                f"issue(s) are: {'; '.join(reasons)}. "
                "These findings refer to the cited policy sections."
            )
        else:
            explanation = (
                f"Your vehicle loan application was rejected, but the "
                f"local rule engine could not identify a specific reason "
                f"from your credit score of {score}, monthly income of "
                f"₹{income:,.0f}, existing EMI of ₹{emi:,.0f}, and "
                f"{exp} years of employment experience. "
                "Review the underwriting decision and relevant policy "
                "passages to establish the actual reason."
            )

    elif decision.strip().lower() == "approved":
        tier = (
            "Tier 1 (Prime)" if score >= 750
            else "Tier 2 (Standard)" if score >= 700
            else "Tier 3"
        )

        rate = (
            8.5 if score >= 750
            else 9.5 if score >= 700
            else 11.0
        )

        foir_cap = 55.0 if income >= 100000 else 50.0

        available_emi = max(
            0.0,
            income * foir_cap / 100.0 - emi
        )

        explanation = (
            f"Your vehicle loan application has been approved. "
            f"Your credit score of {score} falls into {tier}, "
            f"corresponding to the configured interest rate of "
            f"{rate:.2f}% per annum. Your monthly income is "
            f"₹{income:,.0f}, and your existing monthly EMI is "
            f"₹{emi:,.0f}. Under the configured {foir_cap:.0f}% "
            f"FOIR limit, your calculated monthly EMI headroom is "
            f"₹{available_emi:,.0f}. Your recorded sanctioned loan "
            f"amount is ₹{sanctioned:,.0f} for {tenure} years; "
            "refer to the retrieved policy passages for the applicable "
            "eligibility and calculation rules."
        )

    else:
        explanation = (
            f"The underwriting system returned the decision "
            f"'{decision}'. Your monthly income is ₹{income:,.0f}, "
            f"your credit score is {score}, your existing monthly EMI "
            f"is ₹{emi:,.0f}, and your employment experience is "
            f"{exp} years. The available information does not establish "
            "a more specific explanation for this decision."
        )

    return ExplainResponse(
        decision=decision,
        explanation=explanation,
        policy_sources=policy_sources
    )
