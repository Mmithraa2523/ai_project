"""Service for vehicle catalogue filtering, affordability lookup, and detail retrieval."""
from typing import Optional
from backend.schemas import VehicleFilterRequest, VehiclesListResponse, VehicleDetailResponse, VehicleItem
from backend.db.database import filter_vehicles, get_vehicle_by_id


def get_affordable_vehicles(request: VehicleFilterRequest) -> VehiclesListResponse:
    """
    Returns list of vehicles affordable within sanctioned loan amount + down payment.
    Calculates estimated monthly EMIs and supports filtering and sorting.
    """
    total_purchasing_power = request.sanctioned_amount + request.down_payment

    raw_list = filter_vehicles(
        max_budget=total_purchasing_power,
        max_emi=request.max_emi,
        body_type=request.body_type,
        fuel_type=request.fuel_type,
        sort_by=request.sort_by
    )

    vehicle_items = [VehicleItem(**v) for v in raw_list]

    guidance = None
    if not vehicle_items:
        guidance = (
            f"No vehicles in the catalogue fit within the total purchasing power of ₹{total_purchasing_power:,.0f}. "
            "To qualify for available models, consider increasing your upfront down payment, "
            "requesting a longer repayment tenure (up to 7 years) to increase loan capacity, "
            "or consolidating existing liabilities to reduce monthly EMI obligations."
        )

    return VehiclesListResponse(
        total_affordable=len(vehicle_items),
        max_purchasing_power=total_purchasing_power,
        vehicles=vehicle_items,
        guidance=guidance
    )


def get_single_vehicle(vehicle_id: str) -> Optional[VehicleDetailResponse]:
    """Retrieve full specifications and brochure documentation for a vehicle."""
    v = get_vehicle_by_id(vehicle_id)
    if not v:
        return None
    return VehicleDetailResponse(**v)
