"""Pydantic schemas for request validation and response serialization."""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Applicant Details & Predict Schemas
# ---------------------------------------------------------------------------
class ApplicantInput(BaseModel):
    monthly_income: float = Field(..., gt=0, description="Monthly net verified income in INR")
    credit_score: int = Field(..., ge=300, le=900, description="Credit Bureau score (300 to 900)")
    employment_years: float = Field(..., ge=0, description="Years of continuous employment/business experience")
    existing_monthly_emi: float = Field(..., ge=0, description="Sum of existing active monthly EMIs in INR")
    requested_tenure_years: int = Field(default=5, ge=1, le=7, description="Desired repayment tenure in years (1 to 7)")
    down_payment_available: float = Field(default=0.0, ge=0, description="Down payment available in INR")
    age: Optional[int] = Field(default=30, ge=18, le=70, description="Applicant age in years")
    employment_type: Optional[str] = Field(default="Salaried", description="Employment type: Salaried or Self-Employed")
    existing_active_loans: Optional[int] = Field(default=1, ge=0, description="Number of currently active loans")
    requested_loan_amount: Optional[float] = Field(default=None, description="Optional requested loan amount")


class PredictResponse(BaseModel):
    decision: str = Field(..., description="'Approved' or 'Rejected'")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Model prediction confidence score")
    summary: str = Field(..., description="High-level decision outcome summary")
    primary_factors: List[str] = Field(default_factory=list, description="Key applicant factors influencing decision")


# ---------------------------------------------------------------------------
# Sanctioned Loan Amount Schemas
# ---------------------------------------------------------------------------
class LoanAmountRequest(BaseModel):
    monthly_income: float = Field(..., gt=0)
    credit_score: int = Field(..., ge=300, le=900)
    existing_monthly_emi: float = Field(..., ge=0)
    requested_tenure_years: int = Field(default=5, ge=1, le=7)
    requested_loan_amount: Optional[float] = None
    employment_type: Optional[str] = "Salaried"


class LoanAmountResponse(BaseModel):
    sanctioned_amount: float = Field(..., description="Maximum sanctioned principal loan amount in INR")
    interest_rate: float = Field(..., description="Annualized fixed interest rate percentage")
    tenure_years: int = Field(..., description="Sanctioned tenure in years")
    tenure_months: int = Field(..., description="Sanctioned tenure in months")
    max_permissible_emi: float = Field(..., description="Maximum allowable monthly EMI for this loan")
    foir_applied: float = Field(..., description="FOIR cap percentage applied (e.g., 50% or 55%)")
    methodology: str = Field(..., description="Explanation of formula and policy boundaries used")
    calculation_steps: Dict[str, Any] = Field(..., description="Step-by-step arithmetic breakdown")


# ---------------------------------------------------------------------------
# Vehicle Recommendation Schemas
# ---------------------------------------------------------------------------
class VehicleFilterRequest(BaseModel):
    sanctioned_amount: float = Field(..., ge=0, description="Approved loan amount in INR")
    down_payment: float = Field(default=0.0, ge=0, description="Down payment available in INR")
    max_emi: Optional[float] = Field(default=None, description="Optional cap on monthly EMI")
    body_type: Optional[str] = Field(default=None, description="Filter by body type (e.g. Hatchback, Sedan, SUV, Electric)")
    fuel_type: Optional[str] = Field(default=None, description="Filter by fuel type (Petrol, Diesel, CNG, Electric)")
    sort_by: Optional[str] = Field(default="price_asc", description="Sorting criterion: price_asc, price_desc, emi_asc, safety_desc")


class VehicleItem(BaseModel):
    vehicle_id: str
    make: str
    model: str
    variant: str
    body_type: str
    fuel_type: str
    transmission: str
    ex_showroom_price: float
    on_road_price: float
    mileage_kmpl_or_range: str
    engine_cc_or_battery: str
    power_bhp: str
    seating_capacity: int
    safety_rating_stars: int
    warranty_years: int
    key_features: str
    brochure_filename: str
    estimated_emi: Optional[float] = None
    brochure_text: Optional[str] = None


class VehicleDetailResponse(VehicleItem):
    pass


class VehiclesListResponse(BaseModel):
    total_affordable: int
    max_purchasing_power: float
    vehicles: List[VehicleItem]
    guidance: Optional[str] = None


# ---------------------------------------------------------------------------
# Policy Grounded Explanation Schemas
# ---------------------------------------------------------------------------
class ExplainRequest(BaseModel):
    decision: str
    monthly_income: float
    credit_score: int
    employment_years: float
    existing_monthly_emi: float
    requested_tenure_years: int
    down_payment: float = 0.0
    sanctioned_amount: Optional[float] = None
    employment_type: Optional[str] = "Salaried"
    requested_loan_amount: Optional[float] = None


class PolicySource(BaseModel):
    document: str
    section: str
    passage: str
    relevance_score: Optional[float] = None


class ExplainResponse(BaseModel):
    decision: str
    explanation: str
    policy_sources: List[PolicySource]


# ---------------------------------------------------------------------------
# Health Schema
# ---------------------------------------------------------------------------
class HealthResponse(BaseModel):
    status: str
    database_connected: bool
    model_loaded: bool
    version: str = "1.0.0"
