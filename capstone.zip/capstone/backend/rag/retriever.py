"""Retrieval module for policy and vehicle brochure passages."""
import os
import json
import math
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
VECTORSTORE_FILE = os.path.join(BASE_DIR, "vectorstore", "document_embeddings.json")

# In-memory index cache
_INDEX_CACHE = None


def load_vectorstore() -> Dict[str, Any]:
    """Load cached vectorstore index from disk."""
    global _INDEX_CACHE
    if _INDEX_CACHE is not None:
        return _INDEX_CACHE

    if not os.path.exists(VECTORSTORE_FILE):
        # Auto-build if not already present
        from backend.rag.ingest import build_and_save_index
        build_and_save_index()

    with open(VECTORSTORE_FILE, "r", encoding="utf-8") as f:
        _INDEX_CACHE = json.load(f)
    return _INDEX_CACHE


def cosine_similarity(v1: List[float], v2: List[float]) -> float:
    """Compute dot product of two normalized vectors."""
    dot = 0.0
    for a, b in zip(v1, v2):
        dot += a * b
    return dot


def retrieve_passages(
    query: str,
    top_k: int = 3,
    doc_type: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Retrieve top matching passages grounded in policy documents or vehicle brochures.
    Supports OpenAI API when OPENAI_API_KEY is available, falling back to local semantic cosine retrieval.
    """
    index = load_vectorstore()
    vocab = index.get("vocabulary", {})
    chunks = index.get("chunks", [])

    # Filter by doc_type if specified (e.g. 'policy' or 'vehicle')
    candidate_chunks = [c for c in chunks if doc_type is None or c.get("doc_type") == doc_type]

    openai_key = os.getenv("OPENAI_API_KEY", "").strip()

    # Fallback to local semantic vector matching (fast, deterministic, zero network dependency)
    from backend.rag.ingest import tokenize, compute_tf_vector
    q_tokens = tokenize(query)
    q_vec = compute_tf_vector(q_tokens, vocab)

    scored = []
    for c in candidate_chunks:
        c_vec = c.get("vector", [])
        score = cosine_similarity(q_vec, c_vec)
        # Boost if query keywords match section title directly
        section_lower = c.get("section", "").lower()
        for tok in q_tokens:
            if tok in section_lower:
                score += 0.15
        scored.append((score, c))

    scored.sort(key=lambda x: x[0], reverse=True)

    results = []
    for score, chunk in scored[:top_k]:
        results.append({
            "doc_id": chunk["doc_id"],
            "source": chunk["source"],
            "section": chunk["section"],
            "text": chunk["text"],
            "score": round(float(score), 4)
        })
    return results
