"""Document ingestion and chunking for policy rules and vehicle brochures."""
import os
import re
import json
import math
from typing import List, Dict, Any

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
POLICY_DIR = os.path.join(BASE_DIR, "data", "documents", "policy")
VEHICLES_DIR = os.path.join(BASE_DIR, "data", "documents", "vehicles")
VECTORSTORE_DIR = os.path.join(BASE_DIR, "vectorstore")


def tokenize(text: str) -> List[str]:
    """Tokenize and normalize text."""
    return re.findall(r"\b[a-zA-Z0-9_]{2,}\b", text.lower())


def compute_tf_vector(tokens: List[str], vocab: Dict[str, int]) -> List[float]:
    """Compute normalized term frequency vector for vocabulary."""
    vec = [0.0] * len(vocab)
    if not tokens:
        return vec
    for tok in tokens:
        if tok in vocab:
            vec[vocab[tok]] += 1.0
    norm = math.sqrt(sum(v * v for v in vec))
    if norm > 0:
        vec = [v / norm for v in vec]
    return vec


def ingest_policy_documents() -> List[Dict[str, Any]]:
    """Chunk policy document by sections."""
    chunks = []
    policy_path = os.path.join(POLICY_DIR, "vehicle_loan_policy.md")
    if not os.path.exists(policy_path):
        return chunks

    with open(policy_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Split by ### Section
    sections = re.split(r"(### Section \d+:[^\n]+)", content)
    # sections will have alternating headers and text
    header = "Overview"
    for part in sections:
        part = part.strip()
        if not part:
            continue
        if part.startswith("### Section"):
            header = part.replace("### ", "").strip()
        else:
            chunks.append({
                "doc_id": f"policy_{len(chunks)+1}",
                "doc_type": "policy",
                "source": "vehicle_loan_policy.md",
                "section": header,
                "text": part
            })
    return chunks


def ingest_vehicle_brochures() -> List[Dict[str, Any]]:
    """Ingest all vehicle brochure documents."""
    chunks = []
    if not os.path.exists(VEHICLES_DIR):
        return chunks

    for fname in sorted(os.listdir(VEHICLES_DIR)):
        if fname.endswith(".txt"):
            fpath = os.path.join(VEHICLES_DIR, fname)
            with open(fpath, "r", encoding="utf-8") as f:
                content = f.read()
            # Extract title line
            first_line = content.split("\n")[0].replace("# Official Vehicle Brochure:", "").strip()
            chunks.append({
                "doc_id": f"brochure_{fname.replace('.txt', '')}",
                "doc_type": "vehicle",
                "source": fname,
                "section": first_line,
                "text": content
            })
    return chunks


def build_and_save_index():
    """Build and save searchable vectorstore index."""
    os.makedirs(VECTORSTORE_DIR, exist_ok=True)
    all_chunks = ingest_policy_documents() + ingest_vehicle_brochures()

    # Build shared vocabulary
    all_words = set()
    tokenized_chunks = []
    for chunk in all_chunks:
        toks = tokenize(chunk["text"] + " " + chunk["section"])
        tokenized_chunks.append(toks)
        all_words.update(toks)

    vocab = {word: idx for idx, word in enumerate(sorted(all_words))}

    # Compute vector for each chunk
    for i, chunk in enumerate(all_chunks):
        chunk["vector"] = compute_tf_vector(tokenized_chunks[i], vocab)

    index_data = {
        "vocabulary": vocab,
        "total_documents": len(all_chunks),
        "chunks": all_chunks
    }

    out_file = os.path.join(VECTORSTORE_DIR, "document_embeddings.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(index_data, f)
    print(f"Vectorstore index saved to {out_file} with {len(all_chunks)} chunks.")
    return out_file


if __name__ == "__main__":
    build_and_save_index()
