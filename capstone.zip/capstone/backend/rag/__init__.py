"""RAG module for document ingestion, embeddings, and retrieval."""
